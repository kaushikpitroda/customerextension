<?php declare(strict_types=1);


namespace Amasty\Customer\Controller\Adminhtml\Customer;


class Index extends \Magento\Backend\App\Action
{

    protected $resultPageFactory;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context  $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Api\Data\AddressInterfaceFactory $dataAddressFactory,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
		\Magento\Framework\Math\Random $mathRandom,
		\Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
		$this->storeManager = $storeManager;
        $this->customerFactory = $customerFactory;
        $this->dataAddressFactory = $dataAddressFactory;
        $this->addressRepository = $addressRepository;
		$this->mathRandom = $mathRandom;
		$this->_customerSession = $customerSession;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		$this->_view->loadLayout();
        $this->_view->renderLayout();
		$customerDatas = $this->getRequest()->getParam('customer');
        if(is_array($customerDatas)) {
			$this->createCustomer($customerDatas);
			$this->_redirect('amasty_quote/quote_create/index/');
        }
    }
	
	public function createCustomer($data) {
		
        $store = $this->storeManager->getStore();
        $storeId = $store->getStoreId();
        $websiteId = $this->storeManager->getStore()->getWebsiteId();
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId($websiteId);
        $customer->loadByEmail($data['basic_information']['email']);// load customer by email to check if customer is availalbe or not
        if(!$customer->getId()){
            /* create customer */
            $customer->setWebsiteId($websiteId)
                    ->setStore($store)
                    ->setFirstname($data['basic_information']['firstname'])
                    ->setLastname($data['basic_information']['lastname'])
                    ->setPrefix($data['address']['prefix'])
                    ->setMobile($data['address']['telephone'])
                    ->setEmail($data['basic_information']['email'])
                    ->setPassword($this->generatePassword(10));
            $customer->save();
			$this->_customerSession->setCustomerDynamic($customer->getId());
	        //$customer->sendNewAccountEmail();


            /* save address as customer */
			
            $address = $this->dataAddressFactory->create();
            $address->setFirstname($data['address']['firstname']);
            $address->setLastname($data['address']['lastname']);
            $address->setTelephone($data['address']['telephone']);

            $street[] = $data['address']['street'];//pass street as array
            $address->setStreet($street);

            $address->setCity($data['address']['city']);
            $address->setCountryId($data['address']['country_id']);
            $address->setPostcode($data['address']['postcode']);
            $address->setRegionId($data['address']['region_id']);
            $address->setIsDefaultShipping($data['address']['default_billing']);
            $address->setIsDefaultBilling($data['address']['default_shipping']);
            $address->setCustomerId($customer->getId());
            try
            {
                $this->addressRepository->save($address);  
            }
            catch (\Exception $e) {
                return __('Error in shipping/billing address.');
            }
        } else {
            return __('Customer is already exist!');
        }
    }
	
	public function generatePassword($length = 10)
    {
        $chars = \Magento\Framework\Math\Random::CHARS_LOWERS
            . \Magento\Framework\Math\Random::CHARS_UPPERS
            . \Magento\Framework\Math\Random::CHARS_DIGITS;

        return $password = $this->mathRandom->getRandomString($length, $chars);
    }
}

